# Java Spring Boot Example
This is a barebones implementation of a Spring Boot application.

## Dependencies
In order to run this application, you will need to install [docker](https://docs.docker.com/install/) on your machine.

## To Run
Open a terminal and ensure your working directory is the root of this generated application

```bash
target-case-study run
```

## To Test
Open a terminal and ensure your working directory is the root of this generated application

```bash
target-case-study test
```

## To Connect to Services
  ### version_api
    Connect from host machine: http://localhost:8001/version_api/
    Connect in docker container: http://services/version_api/
  ### product_info_api
    Connect from host machine: http://localhost:8001/product_info_api/
    Connect in docker container: http://services/product_info_api/
